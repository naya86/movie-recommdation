import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='naya86',
    application_name='movie-recommandation',
    app_uid='9PMT2RRCzjLzJzlTpg',
    org_uid='ce5fae0f-85f8-407c-86e9-064d3a9392ce',
    deployment_uid='0aa466e5-2a82-4e1e-9094-6007cb5bcb73',
    service_name='movie-recommandation',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'movie-recommandation-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
